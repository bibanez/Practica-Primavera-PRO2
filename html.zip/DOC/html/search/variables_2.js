var searchData=
[
  ['c_0',['C',['../class_categories.html#a666db38464a39984605f0e28e1bc6324',1,'Categories']]],
  ['c_1',['c',['../class_tournament.html#a7579bcfe54a9e15e046909e20e05f612',1,'Tournament']]],
  ['ctg_5fscores_2',['ctg_scores',['../class_categories.html#a133d4a3f71b7435f77e54b5dee7b6c00',1,'Categories']]]
];
