var searchData=
[
  ['names_0',['names',['../class_categories.html#a3b964923b31cde90c72848e6647c2ee8',1,'Categories::names()'],['../class_tournament.html#acfb2bd8b0f7e1afe78b4d9b2ee87eb51',1,'Tournament::names()']]]
];
