var searchData=
[
  ['games_5flost_0',['games_lost',['../class_statistics.html#a16407fea5b227ccc221b1fb38cb8a74c',1,'Statistics']]],
  ['games_5fwon_1',['games_won',['../class_statistics.html#a764b77298e5b22d27621673424591845',1,'Statistics']]]
];
