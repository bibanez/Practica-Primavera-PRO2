var searchData=
[
  ['b_0',['b',['../struct_tournament_1_1match.html#aef1a51b23e51581f8872e89516705221',1,'Tournament::match']]]
];
