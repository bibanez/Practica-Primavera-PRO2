var searchData=
[
  ['tournaments_0',['tournaments',['../class_statistics.html#ae2a6f6821bca9d68341591ebd2c527d7',1,'Statistics::tournaments()'],['../class_tournaments.html#af96fda75ec435fa02c6595805bb92b18',1,'Tournaments::tournaments()']]]
];
