var searchData=
[
  ['sets_5flost_0',['sets_lost',['../class_statistics.html#a59fd9776be1aaba070bcf07a7fe75223',1,'Statistics']]],
  ['sets_5fwon_1',['sets_won',['../class_statistics.html#aac371279328f1370825e92fb408897b5',1,'Statistics']]],
  ['started_2',['started',['../class_tournament.html#a4439410153ce6038f98e33b8812686e9',1,'Tournament']]],
  ['stats_3',['stats',['../class_ranking.html#a5cfe9d31120562c9aed58f6aa0881d25',1,'Ranking::stats()'],['../class_tournament.html#ad3810f23db0329a5b11ad66316612537',1,'Tournament::stats()']]]
];
