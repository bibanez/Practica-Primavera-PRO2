var searchData=
[
  ['get_5fcategory_0',['get_category',['../class_tournament.html#a4648690ed8b2360f09468922d54e11d5',1,'Tournament']]],
  ['get_5fctg_5fscores_1',['get_ctg_scores',['../class_categories.html#a708f9b0e824e3ddd69897336eba93c90',1,'Categories']]],
  ['get_5fgames_5flost_2',['get_games_lost',['../class_statistics.html#a9d8bfb495739375e83bad8a243329985',1,'Statistics']]],
  ['get_5fgames_5fwon_3',['get_games_won',['../class_statistics.html#a364605762dea27e3b46ce081ef821df9',1,'Statistics']]],
  ['get_5fmatches_5flost_4',['get_matches_lost',['../class_statistics.html#af0dba6690ee022c9ac5925a40f4355a9',1,'Statistics']]],
  ['get_5fmatches_5fwon_5',['get_matches_won',['../class_statistics.html#afa9252dfee154d7e24bb87c61a7a0d75',1,'Statistics']]],
  ['get_5fname_6',['get_name',['../class_categories.html#aac421f34e0afd755e181b08c401a7a6a',1,'Categories::get_name()'],['../class_ranking.html#a1db0c257fd2ceda3d4771ef1bdbe27d5',1,'Ranking::get_name(int n) const']]],
  ['get_5fnames_5ffrom_5frankings_7',['get_names_from_rankings',['../class_ranking.html#a0217927ec1a3c9c038a39668c51921da',1,'Ranking']]],
  ['get_5fold_5fresults_8',['get_old_results',['../class_tournament.html#afd4f12c053ce5ee946d8d22de28ef2d2',1,'Tournament']]],
  ['get_5fpoints_9',['get_points',['../class_statistics.html#ae1196c0d787e9dfe3a71161d9f25b57b',1,'Statistics']]],
  ['get_5frank_5fdepth_10',['get_rank_depth',['../class_categories.html#a7b377582ccad7e69d2a0af98e2109e14',1,'Categories']]],
  ['get_5franking_11',['get_ranking',['../class_player.html#ae2d04c85bd624be8b2d19e11206b1a16',1,'Player::get_ranking()'],['../class_ranking.html#ac34919621a76529cc800125179f94ad8',1,'Ranking::get_ranking()']]],
  ['get_5fsets_5flost_12',['get_sets_lost',['../class_statistics.html#a0a262384af152cb440bcaf58544497f4',1,'Statistics']]],
  ['get_5fsets_5fwon_13',['get_sets_won',['../class_statistics.html#a8600132572eb7fc675192414d55f1c17',1,'Statistics']]],
  ['get_5ftournaments_14',['get_tournaments',['../class_statistics.html#a982df5a5d2e58a63a3af3e1d99b8fa55',1,'Statistics']]]
];
