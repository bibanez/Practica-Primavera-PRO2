var searchData=
[
  ['match_0',['match',['../struct_tournament_1_1match.html',1,'Tournament']]]
];
