var searchData=
[
  ['update_5franking_0',['update_ranking',['../class_ranking.html#a9255a4308513c4ad3faee3af2d407a52',1,'Ranking']]]
];
