var searchData=
[
  ['ranking_0',['Ranking',['../class_ranking.html#a7b1142b455d06f3d455d796ed329118f',1,'Ranking']]],
  ['read_5fcategories_1',['read_categories',['../class_categories.html#a2c0e6373cb8a311ced54225437c11bda',1,'Categories']]],
  ['read_5fmatch_2',['read_match',['../class_tournament.html#a6017c0cecaf54bd2ef0be5b8f8d34b56',1,'Tournament']]],
  ['read_5fmatches_3',['read_matches',['../class_tournament.html#ad27bf69341d9d4ad2bd3d863ad6f0747',1,'Tournament']]],
  ['read_5fplayers_4',['read_players',['../class_ranking.html#ab5aee24457c107c1890499d0ac592183',1,'Ranking']]],
  ['read_5fstarting_5ftournaments_5',['read_starting_tournaments',['../class_tournaments.html#ac217a8c9770e82a65d4a261d5a6b1f41',1,'Tournaments']]],
  ['remove_5fplayer_6',['remove_player',['../class_ranking.html#aaa4eb88f2f5f6478940923ee49a9f596',1,'Ranking::remove_player(const string &amp;name)'],['../class_ranking.html#a76f06c55d7fb35eaba2dabf3b64d8b03',1,'Ranking::remove_player(int n)'],['../class_tournaments.html#a15187a808bde2dbab6fb29e01212c50b',1,'Tournaments::remove_player()']]],
  ['remove_5fplayer_5ffrom_5fresults_7',['remove_player_from_results',['../class_tournament.html#aabebb280fb2d4da7e95160a055cde31c',1,'Tournament']]],
  ['remove_5ftournament_8',['remove_tournament',['../class_tournaments.html#ab0ef3fa797244ba147d71d0c2082d28f',1,'Tournaments']]],
  ['right_9',['right',['../class_bin_tree.html#aff8e96651b27284c329667b5ad3e4d0b',1,'BinTree']]]
];
