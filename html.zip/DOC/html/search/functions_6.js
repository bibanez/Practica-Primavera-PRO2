var searchData=
[
  ['has_5fstarted_0',['has_started',['../class_tournament.html#a84e2f41b58f2654ff2b84d18679e1c2c',1,'Tournament']]]
];
