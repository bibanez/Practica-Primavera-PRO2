var searchData=
[
  ['set_5fgames_5flost_0',['set_games_lost',['../class_statistics.html#a08824e077af9a690352935cae5c0e8ac',1,'Statistics']]],
  ['set_5fgames_5fwon_1',['set_games_won',['../class_statistics.html#a365f32c4787f2efac6e3b0b9872c2910',1,'Statistics']]],
  ['set_5fmatches_5flost_2',['set_matches_lost',['../class_statistics.html#a3e10891474345b61c7904bbd04af19e5',1,'Statistics']]],
  ['set_5fmatches_5fwon_3',['set_matches_won',['../class_statistics.html#a09c9fe8d7059df6aab872513228eb0c8',1,'Statistics']]],
  ['set_5fpoints_4',['set_points',['../class_statistics.html#a5dd7afe22bc74689387a27315a6039b7',1,'Statistics']]],
  ['set_5franking_5',['set_ranking',['../class_player.html#a3544f62609a4504bc4b8d217ab4ed5e3',1,'Player']]],
  ['set_5fsets_5flost_6',['set_sets_lost',['../class_statistics.html#a0e43fe14491540195dd01ee81f81cb49',1,'Statistics']]],
  ['set_5fsets_5fwon_7',['set_sets_won',['../class_statistics.html#a812bb705484b4bbf1cd71808dc2e15b0',1,'Statistics']]],
  ['set_5ftournaments_8',['set_tournaments',['../class_statistics.html#a41f54794e71c50102dc5cfb5d40297d9',1,'Statistics']]],
  ['sets_5flost_9',['sets_lost',['../class_statistics.html#a59fd9776be1aaba070bcf07a7fe75223',1,'Statistics']]],
  ['sets_5fwon_10',['sets_won',['../class_statistics.html#aac371279328f1370825e92fb408897b5',1,'Statistics']]],
  ['sort_5franking_11',['sort_ranking',['../class_ranking.html#a48a68ae2dac22a5d7e33fb0db6213445',1,'Ranking']]],
  ['start_5ftournament_12',['start_tournament',['../class_tournaments.html#aa7155bedfeffde88f505e909d35100ad',1,'Tournaments::start_tournament()'],['../class_tournament.html#a472c936ae35e595c94fad08a3d329ae8',1,'Tournament::start_tournament(const vector&lt; string &gt; &amp;players)']]],
  ['started_13',['started',['../class_tournament.html#a4439410153ce6038f98e33b8812686e9',1,'Tournament']]],
  ['statistics_14',['Statistics',['../class_statistics.html#a60ddd90a571ed4c3ce8c0f6317a36d63',1,'Statistics::Statistics()'],['../class_statistics.html#a00267ff63545946e7068e1b70137050d',1,'Statistics::Statistics(int tournaments)'],['../class_statistics.html',1,'Statistics']]],
  ['statistics_2ecc_15',['Statistics.cc',['../_statistics_8cc.html',1,'']]],
  ['statistics_2ehh_16',['Statistics.hh',['../_statistics_8hh.html',1,'']]],
  ['stats_17',['stats',['../class_ranking.html#a5cfe9d31120562c9aed58f6aa0881d25',1,'Ranking::stats()'],['../class_tournament.html#ad3810f23db0329a5b11ad66316612537',1,'Tournament::stats()']]]
];
