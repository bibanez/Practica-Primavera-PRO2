var searchData=
[
  ['player_5fit_0',['Player_it',['../class_ranking.html#a7873924f1054c9096d5ab28aaf0c69af',1,'Ranking']]]
];
