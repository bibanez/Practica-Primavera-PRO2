var searchData=
[
  ['old_5fresults_0',['old_results',['../class_tournament.html#a26f1887884bb9c6e4da3be5acdc9a154',1,'Tournament']]]
];
