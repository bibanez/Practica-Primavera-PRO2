var searchData=
[
  ['tournament_0',['Tournament',['../class_tournament.html#ad28a8cda268e707f934a4905070a2c6a',1,'Tournament::Tournament(int c)'],['../class_tournament.html#a87cc832c6612caebcab61d1bea7ef1ac',1,'Tournament::Tournament()']]]
];
