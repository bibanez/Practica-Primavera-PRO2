var searchData=
[
  ['first_5fwins_0',['first_wins',['../class_tournament.html#ac2be35fd28775a749d486bca65dee589',1,'Tournament']]]
];
