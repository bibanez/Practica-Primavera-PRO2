var searchData=
[
  ['categories_0',['Categories',['../class_categories.html',1,'']]]
];
