var searchData=
[
  ['práctica_20de_20pro2_20primavera_202022_3a_20gestión_20de_20una_20liga_20de_20tenis_20profesional_2e_0',['Práctica de PRO2 primavera 2022: Gestión de una liga de tenis profesional.',['../index.html',1,'']]]
];
