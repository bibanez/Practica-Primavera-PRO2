var searchData=
[
  ['matches_5flost_0',['matches_lost',['../class_statistics.html#a9b3e470743914d2d3225b3b72a7582cb',1,'Statistics']]],
  ['matches_5fwon_1',['matches_won',['../class_statistics.html#a55ceb6b864ad1ae0b332bd4b9bb60e6f',1,'Statistics']]]
];
