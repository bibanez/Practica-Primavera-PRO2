var searchData=
[
  ['main_0',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['match_1',['match',['../struct_tournament_1_1match.html',1,'Tournament']]],
  ['matches_5flost_2',['matches_lost',['../class_statistics.html#a9b3e470743914d2d3225b3b72a7582cb',1,'Statistics']]],
  ['matches_5fwon_3',['matches_won',['../class_statistics.html#a55ceb6b864ad1ae0b332bd4b9bb60e6f',1,'Statistics']]]
];
