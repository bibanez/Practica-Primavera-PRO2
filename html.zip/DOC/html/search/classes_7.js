var searchData=
[
  ['tournament_0',['Tournament',['../class_tournament.html',1,'']]],
  ['tournaments_1',['Tournaments',['../class_tournaments.html',1,'']]]
];
