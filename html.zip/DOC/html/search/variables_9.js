var searchData=
[
  ['p_0',['p',['../class_bin_tree.html#afe3647af1dda90f6ddf1deee6560fcf1',1,'BinTree']]],
  ['points_1',['points',['../class_statistics.html#a38bd96be45562d8f2d1377043343561e',1,'Statistics']]]
];
