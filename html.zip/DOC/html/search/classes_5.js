var searchData=
[
  ['ranking_0',['Ranking',['../class_ranking.html',1,'']]]
];
