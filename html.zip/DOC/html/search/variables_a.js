var searchData=
[
  ['ranking_0',['ranking',['../class_player.html#ac793ef1d1e7c66b3b4a81a8b4ed005a5',1,'Player::ranking()'],['../class_ranking.html#a83bb955fd258ec28f9012b975ce2e22d',1,'Ranking::ranking()']]],
  ['result_1',['result',['../struct_tournament_1_1match.html#a889ca0a4f980ac583112300a4e839579',1,'Tournament::match']]],
  ['results_2',['results',['../class_tournament.html#ac7ef77498f66d128fc0fe65a7b11aaf5',1,'Tournament']]],
  ['right_3',['right',['../struct_bin_tree_1_1_node.html#a6df770137090da60cd0376ce06893cbd',1,'BinTree::Node']]]
];
