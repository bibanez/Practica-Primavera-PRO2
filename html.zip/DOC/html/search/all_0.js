var searchData=
[
  ['a_0',['a',['../struct_tournament_1_1match.html#a8de43a7462ae0779c89f1de2276cc421',1,'Tournament::match']]],
  ['add_5fplayer_1',['add_player',['../class_ranking.html#a11edd6bdb619ca3cfb63b891522b882d',1,'Ranking']]],
  ['add_5fstats_2',['add_stats',['../class_statistics.html#a3e2e905f930be0f993d0187ed8388206',1,'Statistics']]],
  ['add_5ftournament_3',['add_tournament',['../class_tournaments.html#aaa45217324659b3ce635c12b131e53a3',1,'Tournaments']]],
  ['add_5ftournament_5fresults_4',['add_tournament_results',['../class_ranking.html#a63dff39266b00b2078fb0b7e900d53e7',1,'Ranking']]]
];
