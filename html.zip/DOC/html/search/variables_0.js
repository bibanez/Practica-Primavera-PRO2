var searchData=
[
  ['a_0',['a',['../struct_tournament_1_1match.html#a8de43a7462ae0779c89f1de2276cc421',1,'Tournament::match']]]
];
